/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabalho01;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author maria
 */
public class Motorista {
    private String numCNH;
    private String nome;
    private Data dtVenci;
    
    public Motorista(String numCNH, String nome, Data dtVenci) {
        this.numCNH = numCNH;
        this.nome = nome;
        this.dtVenci = dtVenci;
    }
    
    public void escreveMotorista() throws IOException{
        FileWriter arq = new FileWriter("motoristas.txt",true);
        BufferedWriter buf = new BufferedWriter(arq);
        
        buf.write(this.numCNH + "\n");
        buf.write(this.nome + "\n");
        buf.write(Integer.toString(this.dtVenci.getDia()) + "\n");
        buf.write(Integer.toString(this.dtVenci.getMes()) + "\n");
        buf.write(Integer.toString(this.dtVenci.getAno()) + "\n");
        buf.close();
    }
    
    /**
     * @return the numCNH
     */
    public String getNumCNH() {
        return numCNH;
    }

    /**
     * @param numCNH the numCNH to set
     */
    public void setNumCNH(String numCNH) {
        this.numCNH = numCNH;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the dtVenci
     */
    public Data getDtVenci() {
        return dtVenci;
    }

    /**
     * @param dtVenci the dtVenci to set
     */
    public void setDtVenci(Data dtVenci) {
        this.dtVenci = dtVenci;
    }
    
}
