/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabalho01;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author maria
 */
public class Sistema {
    private ArrayList<Motorista> motoristas;
    private ArrayList<Veiculo> veiculos;
    private ArrayList<Infracao> infracoes;
    private ArrayList<Natureza> naturezas;
    
    Sistema() {
        this.motoristas = new ArrayList<>();
        this.veiculos = new ArrayList<>();
        this.infracoes = new ArrayList<>();
        this.naturezas = new ArrayList<>();
        this.naturezas.add(new Natureza("Leve",3));
        this.naturezas.add(new Natureza("Media",4));
        this.naturezas.add(new Natureza("Grave",5));
        this.naturezas.add(new Natureza("Gravissima",7));
    }
    
    public void lerMotoristas() throws FileNotFoundException, IOException{
        FileReader arq = new FileReader("motoristas.txt");
        BufferedReader buf = new BufferedReader(arq);
        
        while(buf.ready()){
            String numCNH = buf.readLine();
            String nome = buf.readLine();
            int dia = Integer.parseInt(buf.readLine());
            int mes = Integer.parseInt(buf.readLine());
            int ano = Integer.parseInt(buf.readLine());
            Data dtVenci = new Data(dia,mes,ano);
            
            Motorista mot = new Motorista(numCNH, nome, dtVenci);
            this.addMotorista(mot);
        }
    }
    
    public void lerVeiculos() throws FileNotFoundException, IOException{
        FileReader arq = new FileReader("veiculos.txt");
        BufferedReader buf = new BufferedReader(arq);
        
        while(buf.ready()){
            String placa = buf.readLine();
            String modelo = buf.readLine();
            String cor = buf.readLine();
            String numCNH = buf.readLine();
            
            Motorista prop = null;
            for (Motorista m : this.motoristas){
                if(numCNH.equals(m.getNumCNH()))  {
                    prop = m;
                }
            }
        
            Veiculo v = new Veiculo(placa, modelo, cor, prop);
            this.addVeiculos(v);
        }
    }
   
    
    public void lerInfracoes() throws FileNotFoundException, IOException{
        FileReader arq = new FileReader("infracoes.txt");
        BufferedReader buf = new BufferedReader(arq);
    
        while(buf.ready()){
            String codigo = buf.readLine();
            int dia = Integer.parseInt(buf.readLine());
            int mes = Integer.parseInt(buf.readLine());
            int ano = Integer.parseInt(buf.readLine());
            Data dtInfracao = new Data(dia,mes,ano);
            String placa = buf.readLine();
            
            Veiculo vMultado = null; 
            for (Veiculo v : this.veiculos){
                if(placa.equals(v.getPlaca())){
                    vMultado  = v;
                }
            }
            
            String confere = buf.readLine();
            Motorista condutor = null;
            for (Motorista m : this.motoristas){
                if (m.getNumCNH().equals(confere)){
                    condutor = m;
                    confere = buf.readLine();
                }
            }
            
            int pontuacao = Integer.parseInt(buf.readLine());
            Natureza natInfra = new Natureza(confere, pontuacao); 
            
            Infracao i = new Infracao(codigo, dtInfracao, vMultado, natInfra);
            i.setCondutor(condutor);
            this.addInfracoes(i);
            
        }
        buf.close();
    }
    
    public void escreveInfracao() throws IOException{
        FileWriter arq = new FileWriter("infracoes.txt",false);
        BufferedWriter buf = new BufferedWriter(arq);
        
        for (Infracao i : this.infracoes){
            buf.write(i.getCodigo() + "\n");
            buf.write(Integer.toString(i.getDtInfracao().getDia()) + "\n");
            buf.write(Integer.toString(i.getDtInfracao().getMes()) + "\n");
            buf.write(Integer.toString(i.getDtInfracao().getAno()) + "\n");
            buf.write(i.getvMultado().getPlaca() + "\n");
            
            if (i.getCondutor() != null){
                buf.write(i.getCondutor().getNumCNH() + "\n");
            }
            
            buf.write(i.getNatInfracao().getTipoInf() + "\n");
            buf.write(Integer.toString(i.getNatInfracao().getPontuacao()) + "\n");
            
        }
        buf.close();
    }
    
    public void addMotorista(Motorista m) {
        this.motoristas.add(m);
    }
    
    public void addVeiculos(Veiculo v) {
        this.veiculos.add(v);
    }
    
    public void addInfracoes(Infracao i) {
        this.infracoes.add(i);
    }
    
    public Motorista getMotorista(int index) {
        return this.motoristas.get(index);
    }
    
    public Veiculo getVeiculo(int index) {
        return this.veiculos.get(index);
    }
    
    public Infracao getInfracao(int index) {
        return this.infracoes.get(index);
    }
    
    public Natureza getNatureza(int index) {
        return this.naturezas.get(index);
    }
    /**
     * @return the motoristas
     */
    public ArrayList<Motorista> getMotoristas() {
        return motoristas;
    }

    /**
     * @param motoristas the motoristas to set
     */
    public void setMotoristas(ArrayList<Motorista> motoristas) {
        this.motoristas = motoristas;
    }

    /**
     * @return the veiculos
     */
    public ArrayList<Veiculo> getVeiculos() {
        return veiculos;
    }

    /**
     * @param veiculos the veiculos to set
     */
    public void setVeiculos(ArrayList<Veiculo> veiculos) {
        this.veiculos = veiculos;
    }

    /**
     * @return the infracoes
     */
    public ArrayList<Infracao> getInfracoes() {
        return infracoes;
    }

    /**
     * @param infracoes the infracoes to set
     */
    public void setInfracoes(ArrayList<Infracao> infracoes) {
        this.infracoes = infracoes;
    }

    /**
     * @return the naturezas
     */
    public ArrayList<Natureza> getNaturezas() {
        return naturezas;
    }

    /**
     * @param naturezas the naturezas to set
     */
    public void setNaturezas(ArrayList<Natureza> naturezas) {
        this.naturezas = naturezas;
    }
    
}
