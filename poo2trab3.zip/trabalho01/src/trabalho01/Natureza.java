/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabalho01;

/**
 *
 * @author maria
 */
public class Natureza {
    private String tipoInf;
    private int pontuacao;
    
    Natureza(String tipoInf, int pontuacao) {
        this.tipoInf = tipoInf;
        this.pontuacao = pontuacao;
    }
    
    
    /**
     * @return the tipoInf
     */
    public String getTipoInf() {
        return tipoInf;
    }

    /**
     * @param tipoInf the tipoInf to set
     */
    public void setTipoInf(String tipoInf) {
        this.tipoInf = tipoInf;
    }

    /**
     * @return the pontuacao
     */
    public int getPontuacao() {
        return pontuacao;
    }

    /**
     * @param pontuacao the pontuacao to set
     */
    public void setPontuacao(int pontuacao) {
        this.pontuacao = pontuacao;
    }

}
