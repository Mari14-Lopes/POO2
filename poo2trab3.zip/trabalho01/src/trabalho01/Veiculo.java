/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabalho01;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author maria
 */
public class Veiculo {
    private String placa;
    private String modelo;
    private String cor;
    private Motorista proprietario;
    
    Veiculo(String placa, String modelo, String cor, Motorista proprietario) {
        this.placa = placa;
        this.modelo = modelo;
        this.cor = cor;
        this.proprietario = proprietario;
        
    }
    
    public void escreveVeiculo() throws IOException{
        FileWriter arq = new FileWriter("veiculos.txt",true);
        BufferedWriter buf = new BufferedWriter(arq);
        
        buf.write(this.placa + "\n");
        buf.write(this.modelo + "\n");
        buf.write(this.cor + "\n");
        buf.write(this.proprietario.getNumCNH() + "\n");
        buf.close();
    }
    
    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the cor
     */
    public String getCor() {
        return cor;
    }

    /**
     * @param cor the cor to set
     */
    public void setCor(String cor) {
        this.cor = cor;
    }

    /**
     * @return the proprietario
     */
    public Motorista getProprietario() {
        return proprietario;
    }

    /**
     * @param proprietario the proprietario to set
     */
    public void setProprietario(Motorista proprietario) {
        this.proprietario = proprietario;
    }

    
}
