/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabalho01;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author maria
 */
public class Infracao {
    private String codigo;
    private Data dtInfracao;
    private Veiculo vMultado;
    private Motorista condutor;
    private Natureza natInfracao;
    
    Infracao(String codigo, Data dtInfracao, Veiculo vMultado, Natureza natInfracao) {
        this.codigo = codigo;
        this.dtInfracao = dtInfracao;
        this.vMultado = vMultado;
        this.condutor = null;
        this.natInfracao = natInfracao;
    }
    
    /**
     * @return the codigo
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the dtInfracao
     */
    public Data getDtInfracao() {
        return dtInfracao;
    }

    /**
     * @param dtInfracao the dtInfracao to set
     */
    public void setDtInfracao(Data dtInfracao) {
        this.dtInfracao = dtInfracao;
    }

    /**
     * @return the vMultado
     */
    public Veiculo getvMultado() {
        return vMultado;
    }

    /**
     * @param vMultado the vMultado to set
     */
    public void setvMultado(Veiculo vMultado) {
        this.vMultado = vMultado;
    }

    /**
     * @return the condutor
     */
    public Motorista getCondutor() {
        return condutor;
    }

    /**
     * @param condutor the condutor to set
     */
    public void setCondutor(Motorista condutor) {
        this.condutor = condutor;
    }

    /**
     * @return the natInfracao
     */
    public Natureza getNatInfracao() {
        return natInfracao;
    }

    /**
     * @param natInfracao the natInfracao to set
     */
    public void setNatInfracao(Natureza natInfracao) {
        this.natInfracao = natInfracao;
    }

}
